package com.sapient.myboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybootApplicationTests {

	@Test
	void contextLoads() {
	}

}
